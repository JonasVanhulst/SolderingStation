/*
#define SETUNUSEDINPUT( IO_PIN  ) {  pinMode(IO_PIN, INPUT); digitalWrite(IO_PIN, HIGH); }           // set pin to input, turn on pullup resistors  

#define PIN_PA0 0
#define PIN_PA1 1
#define PIN_PA2 2
#define PIN_PA3 3
#define PIN_PA4 4
#define PIN_PA5 5
#define PIN_PA6 6
#define PIN_PA7 7
#define PIN_PB0 8
#define PIN_PB1 9
#define PIN_PB2 10
#define PIN_PB3 11
#define PIN_PB4 12
#define PIN_PB5 13
#define PIN_PC0 14
#define PIN_PC1 15
#define PIN_PC2 16
#define PIN_PC3 17
#define PIN_PC4 18
#define PIN_PC5 19
#define PIN_PC6 20
#define PIN_PC7 21
#define PIN_PD0 22
#define PIN_PD1 23
#define PIN_PD2 24
#define PIN_PD3 25
#define PIN_PD4 26
#define PIN_PD5 27
#define PIN_PD6 28
#define PIN_PD7 29
#define PIN_PE0 30
#define PIN_PE1 31
#define PIN_PE2 32
#define PIN_PE3 33
#define PIN_PF0 34
#define PIN_PF1 35
#define PIN_PF2 36
#define PIN_PF3 37
#define PIN_PF4 38
#define PIN_PF5 39
#define PIN_PF6 40
*/