#ifndef __CURRENT_190409_H__
 #define __CURRENT_190409_H__

    class CURRENT_190409 {

        private:

        public:
         CURRENT_190409( void ){};
    }; 

#endif